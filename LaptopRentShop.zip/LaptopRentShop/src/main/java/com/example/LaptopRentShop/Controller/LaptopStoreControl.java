package com.example.LaptopRentShop.Controller;

import com.example.LaptopRentShop.Model.LaptopStore;
import com.example.LaptopRentShop.Service.LaptopStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class LaptopStoreControl {
    @Autowired
    LaptopStoreService srsobj;

    @PostMapping("/addProduct")
    public String productAdd(@RequestBody LaptopStore sobj){
        srsobj.addlaptop(sobj);
        return "laptop added";
    }
    @GetMapping("/displayAllProduct")
    public List<LaptopStore> displayAllProduct(){
        return srsobj.displayallproduct();
    }
    @GetMapping("/displayProductByID/{laptopid}")
    public Optional<LaptopStore> dispayId(@PathVariable int laptopid){
        return srsobj.displayproductbyid(laptopid);
    }
    @DeleteMapping("/deleteAllProduct")
    public String deleteAll(){
        return srsobj.deleteallproduct();
    }
    @DeleteMapping("/deleteProductByID/{laptopid}")
    public String deleteId(@PathVariable int laptopid){
        return srsobj.deleteproductbyid(laptopid);
    }
    @PutMapping("/updateProduct/{laptopid}")
    public String productUpdate(@PathVariable int laptopid, @RequestBody LaptopStore sobj){
        return srsobj.updateprodut(laptopid, sobj);
    }


}
