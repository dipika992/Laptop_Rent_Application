package com.example.LaptopRentShop.Controller;

import com.example.LaptopRentShop.Model.BookingRent;
import com.example.LaptopRentShop.Service.BookingRentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class BookingRentControl {
    @Autowired
    BookingRentService osobj;

    @GetMapping("/")
    public String home() {
        return "HELLO EVERYONE WELCOME TO Laptop Rental Website";
    }

    @PostMapping("/addOrder")
    public String orderAdd(@RequestBody BookingRent orderobj) {
        osobj.addorder(orderobj);
        return "Booking added";
    }

    @GetMapping("/displayAllOrder")
    public List<BookingRent> displayAllOrder() {
        return osobj.odisplayall();
    }

    @GetMapping("/displayOrderByID/{rentid}")
    public Optional<BookingRent> displayId(@PathVariable int rentid) {
        return osobj.odisplaybyid(rentid);
    }

    @DeleteMapping("/deleteAllOrder")
    public String deleteAll() {
        return osobj.odeleteall();
    }

    @DeleteMapping("/deleteOrderByID/{rentid}")
    public String deleteId(@PathVariable int rentid) {
        return osobj.odeletebyid(rentid);
    }

    @PutMapping("/updateOrder/{rentid}")
    public String Update(@PathVariable int rentid, @RequestBody BookingRent orderobj) {
        return osobj.oupdate(rentid, orderobj);
    }
}

