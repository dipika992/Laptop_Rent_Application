package com.example.LaptopRentShop.Model;
import lombok.*;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {
    //user can be admin or manager or customer
    @Id
    private int id;
    private String password;
    private String username;
    private String role;
}
