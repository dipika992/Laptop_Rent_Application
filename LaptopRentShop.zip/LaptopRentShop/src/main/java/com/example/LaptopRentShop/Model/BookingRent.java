package com.example.LaptopRentShop.Model;
import lombok.*;
import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class BookingRent {
    @Id
    private int rentid;
    private int totaltime;
    private String name;
    private String panno;
    private int price;
    @ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinColumn(name="laptopid")
    private LaptopStore laptopStoreobj;
}
