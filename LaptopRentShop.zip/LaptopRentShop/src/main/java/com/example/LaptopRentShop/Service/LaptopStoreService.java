package com.example.LaptopRentShop.Service;

import com.example.LaptopRentShop.Model.LaptopStore;
import com.example.LaptopRentShop.Repository.LaptopStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class LaptopStoreService {
    @Autowired
    LaptopStoreRepository storerepobj;
    public void addlaptop(LaptopStore storeobj) {

        storerepobj.save(storeobj);
    }

    public List<LaptopStore> displayallproduct() {

        return storerepobj.findAll();
    }

    public Optional<LaptopStore> displayproductbyid(int laptopid) {
        return storerepobj.findById(laptopid);
    }

    public String deleteallproduct() {
        storerepobj.deleteAll();
        return "All Laptop records are deleted";
    }
    public String deleteproductbyid(int laptopid) {
        storerepobj.deleteById(laptopid);
        return "Laptop Product is deleted";
    }

    public String updateprodut(int laptopid, LaptopStore storeobj) {
        if(storerepobj.findById(laptopid)!=null){
            storerepobj.deleteById(laptopid);
            storerepobj.save(storeobj);
            return "updated";
        }
        return "Laptop Product does not exist in database";
    }

}
