package com.example.LaptopRentShop.Repository;

import com.example.LaptopRentShop.Model.BookingRent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRentRepository extends JpaRepository<BookingRent,Integer> {

}
