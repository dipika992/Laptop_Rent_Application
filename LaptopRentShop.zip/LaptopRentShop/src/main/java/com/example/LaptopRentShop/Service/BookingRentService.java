package com.example.LaptopRentShop.Service;

import com.example.LaptopRentShop.Model.BookingRent;
import com.example.LaptopRentShop.Repository.BookingRentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service
public class BookingRentService {
    @Autowired
    BookingRentRepository orderrepobj;
    public void addorder(BookingRent orderobj) {

        orderrepobj.save(orderobj);
    }
    public List<BookingRent> odisplayall() {

        return orderrepobj.findAll();
    }

    public Optional<BookingRent> odisplaybyid(int rentid) {

        return orderrepobj.findById(rentid);
    }

    public String odeleteall() {
        orderrepobj.deleteAll();
        return "all Rent records are deleted";
    }
    public String odeletebyid(int rentid) {
        orderrepobj.deleteById(rentid);
        return "Rent record is deleted";
    }

    public String oupdate(int rentid, BookingRent bookobj) {
        if(orderrepobj.findById(rentid)!=null){
            orderrepobj.deleteById(rentid);
            orderrepobj.save(bookobj);
            return "updated";
        }
        return "Rent id does not exist in database";
    }
}
