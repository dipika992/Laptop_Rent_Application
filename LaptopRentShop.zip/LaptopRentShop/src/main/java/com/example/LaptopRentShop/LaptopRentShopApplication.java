package com.example.LaptopRentShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopRentShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptopRentShopApplication.class, args);
	}

}
