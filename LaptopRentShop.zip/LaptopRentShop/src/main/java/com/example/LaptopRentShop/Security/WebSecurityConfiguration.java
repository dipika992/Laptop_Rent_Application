package com.example.LaptopRentShop.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
    @Autowired
    private UserDetailsService userDetailsServiceObject;

    AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authenticationProviderObject = new DaoAuthenticationProvider();
        authenticationProviderObject.setPasswordEncoder(passwordEncoder());
        authenticationProviderObject.setUserDetailsService(userDetailsServiceObject);
        return authenticationProvider();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        http.cors().disable();
        http.authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/addProduct").hasAuthority("admin")
                .antMatchers("/displayAllProduct").hasAnyAuthority("user","admin")
                .antMatchers("/displayProductByID/{laptopid}").hasAnyAuthority("user","admin")
                .antMatchers("/deleteAllProduct").hasAuthority("admin")
                .antMatchers("/deleteProductByID/{laptopid}").hasAuthority("admin")
                .antMatchers("/updateProduct/{laptopid}").hasAnyAuthority("admin","manager")
                .antMatchers("/addOrder").hasAuthority("user")
                .antMatchers("/displayAllOrder").hasAuthority("manager")
                .antMatchers("/displayOrderByID/{rentid}").hasAnyAuthority("user","manager")
                .antMatchers("/deleteAllOrder").hasAuthority("manager")
                .antMatchers("/deleteOrderByID/{rentid}").hasAnyAuthority("user","manager")
                .antMatchers("/updateOrder/{rentid}").hasAnyAuthority("user","manager")
                .anyRequest().authenticated().and().httpBasic();

    }
}
